/**
 * @fileoverview Externs for Polymer
 * @externs
 */

/**
 * @param {!{is: string}} init
 * @return {!CustomElement}
 */
function Polymer(init){}